A translation of the blog theme scribbish to pyblosxom, by seanh. The one thing I didn't like about scribbish was its lack of colour, so I added some :)

Please email any comments, suggestions, improvements to seanh at freeshell dot org.

Scribbish is minimalist in style, easy to modify and features a simple XHTML structure and blog entries formatted according to the hAtom microformat specification.

Scribbish is copyright Jeffrey Hardyunder the MIT license: <http://www.opensource.org/licenses/mit-license.php>
